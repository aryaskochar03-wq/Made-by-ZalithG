# Object Detector (Android / Kotlin)

Live camera app that draws a bounding box + label over everyday objects
(TV, laptop, chair, couch, cup, book, etc. — the 80 standard COCO classes)
in real time, using CameraX for the camera feed and MediaPipe Tasks Vision
for on-device object detection.

## How it works

- `MainActivity.kt` — sets up CameraX, streams frames to a MediaPipe
  `ObjectDetector` running in `LIVE_STREAM` mode, and receives results
  asynchronously via a callback.
- `OverlayView.kt` — a transparent view drawn on top of the camera preview
  that renders a rectangle + label for every detection.
- `activity_main.xml` — stacks `PreviewView` (camera) and `OverlayView`
  (boxes) in a `FrameLayout`.

## One manual step required: download the model

Model files are binary and aren't included in source form. Before building:

1. Download `efficientdet_lite0.tflite` (or `_lite2` for higher accuracy,
   slower speed) from MediaPipe's model index:
   https://ai.google.dev/edge/mediapipe/solutions/vision/object_detector/index#models
2. Place it at:
   ```
   app/src/main/assets/efficientdet_lite0.tflite
   ```
3. If you use a different filename or model, update `MODEL_FILE` in
   `MainActivity.kt`.

## Build & run (with a computer / Android Studio)

1. Open the `ObjectDetectorApp` folder in Android Studio (Hedgehog or newer).
2. Let Gradle sync (it will pull CameraX + MediaPipe Tasks Vision deps
   automatically).
3. Connect an Android device (API 24+) with a camera, or use an emulator
   with camera support.
4. Run. Grant the camera permission when prompted.

## Build & run (phone only, no computer — via GitHub Actions)

This project includes `.github/workflows/build.yml`, which builds the APK
on GitHub's servers. You never need Android Studio.

1. **Create a GitHub account** (github.com or the GitHub mobile app) if you
   don't have one.
2. **Create a new repository** — name it anything, e.g. `object-detector`.
   Public or private both work.
3. **Upload the project files**:
   - In the GitHub app or website, go to your new repo → "Add file" →
     "Upload files."
   - Upload everything from the unzipped `ObjectDetectorApp` folder,
     preserving the folder structure (`app/`, `.github/`, `build.gradle`,
     `settings.gradle`, `gradle.properties`, `README.md`).
   - **Important:** also upload `efficientdet_lite0.tflite` into
     `app/src/main/assets/` — the app will crash on launch without it.
4. **Commit the files** (the upload screen has a "Commit changes" button).
   Committing to `main` automatically triggers the build workflow.
5. **Check the build**: go to the "Actions" tab in your repo. You'll see
   a "Build APK" run in progress (takes a few minutes).
6. **Download the APK**: once it finishes (green checkmark), open that
   run, scroll to "Artifacts," and download `app-debug-apk` — it's a zip
   containing `app-debug.apk`.
7. **Install on your phone**: unzip it (a file manager app can do this),
   tap the `.apk` file, and allow "install from unknown sources" if
   prompted. This is a debug build, fine for personal use but not signed
   for the Play Store.

If a build fails, open the failed step in the Actions log — it'll usually
point to a missing file or typo from the upload step.

## Customizing

- **Confidence threshold** — `setScoreThreshold(0.5f)` in
  `setupObjectDetector()`. Lower = more (noisier) detections.
- **Max simultaneous detections** — `setMaxResults(10)`.
- **Box/text styling** — colors in `res/values/colors.xml`, stroke width
  and text size in `OverlayView.kt`.
- **Front camera instead of back** — change `CameraSelector.DEFAULT_BACK_CAMERA`
  to `DEFAULT_FRONT_CAMERA` in `startCamera()`.
- **Restrict to specific classes** — MediaPipe's `ObjectDetectorOptions`
  supports `setCategoryAllowlist(listOf("tv", "laptop", "chair", ...))` if
  you only want a subset of COCO's 80 classes.

## Full COCO class list

person, bicycle, car, motorcycle, airplane, bus, train, truck, boat,
traffic light, fire hydrant, stop sign, parking meter, bench, bird, cat,
dog, horse, sheep, cow, elephant, bear, zebra, giraffe, backpack, umbrella,
handbag, tie, suitcase, frisbee, skis, snowboard, sports ball, kite,
baseball bat, baseball glove, skateboard, surfboard, tennis racket,
bottle, wine glass, cup, fork, knife, spoon, bowl, banana, apple,
sandwich, orange, broccoli, carrot, hot dog, pizza, donut, cake, chair,
couch, potted plant, bed, dining table, toilet, tv, laptop, mouse,
remote, keyboard, cell phone, microwave, oven, toaster, sink,
refrigerator, book, clock, vase, scissors, teddy bear, hair drier,
toothbrush

(Note: "trash can" / "trash bin" is not a stock COCO class — if you need
it, you'd fine-tune a custom model or swap in a different pretrained
detector that includes it.)
