package com.example.objectdetector

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.toBitmap
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectorResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Live camera object detection.
 *
 * Draws a bounding box + label over every detected object (TV, laptop,
 * chair, couch, etc. — the 80 COCO classes) in real time using MediaPipe's
 * on-device Object Detector running on the GPU/CPU delegate.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlayView: OverlayView
    private lateinit var inferenceTimeText: TextView

    private var objectDetector: ObjectDetector? = null
    private lateinit var cameraExecutor: ExecutorService

    private val requestPermissionLauncher =
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.viewFinder)
        overlayView = findViewById(R.id.overlayView)
        inferenceTimeText = findViewById(R.id.inferenceTimeText)

        cameraExecutor = Executors.newSingleThreadExecutor()

        if (hasCameraPermission()) {
            setupObjectDetector()
            startCamera()
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE
            )
        }
    }

    private fun hasCameraPermission() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE &&
            grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            setupObjectDetector()
            startCamera()
        }
    }

    /**
     * Loads the EfficientDet-Lite model bundled in assets/ and configures
     * the detector to run in LIVE_STREAM mode so results stream back via
     * a callback as camera frames arrive.
     */
    private fun setupObjectDetector() {
        val baseOptions = BaseOptions.builder()
            .setModelAssetPath(MODEL_FILE)
            .build()

        val options = ObjectDetector.ObjectDetectorOptions.builder()
            .setBaseOptions(baseOptions)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setMaxResults(10)
            .setScoreThreshold(0.5f)
            .setResultListener(this::onDetectionResult)
            .setErrorListener { e -> Log.e(TAG, "Detector error: ${e.message}") }
            .build()

        objectDetector = ObjectDetector.createFromOptions(this, options)
    }

    private fun onDetectionResult(result: ObjectDetectorResult, inputImageHeight: Int, inputImageWidth: Int) {
        val inferenceTimeMs = SystemClock.uptimeMillis() - result.timestampMs()
        runOnUiThread {
            inferenceTimeText.text = "${inferenceTimeMs} ms"
            overlayView.setResults(result.detections(), inputImageHeight, inputImageWidth)
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { imageProxy ->
                        detectObjects(imageProxy)
                    }
                }

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageAnalyzer
                )
            } catch (exc: Exception) {
                Log.e(TAG, "Camera binding failed", exc)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /**
     * Converts each camera frame to a MediaPipe MPImage and feeds it to
     * the detector asynchronously (LIVE_STREAM mode).
     */
    private fun detectObjects(imageProxy: ImageProxy) {
        val bitmap = imageProxy.toBitmap()
        val mpImage = BitmapImageBuilder(bitmap).build()

        objectDetector?.detectAsync(mpImage, SystemClock.uptimeMillis())
        imageProxy.close()
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        objectDetector?.close()
    }

    companion object {
        private const val TAG = "ObjectDetectorApp"
        private const val CAMERA_PERMISSION_CODE = 10
        // Place efficientdet_lite0.tflite (or similar MediaPipe object
        // detector model) in app/src/main/assets/
        private const val MODEL_FILE = "efficientdet_lite0.tflite"
    }
}
