package com.example.objectdetector

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import com.google.mediapipe.tasks.components.containers.Detection
import kotlin.math.max

/**
 * Custom view that draws bounding boxes + class labels on top of the
 * live camera preview, based on the latest ObjectDetector results.
 */
class OverlayView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private var results: List<Detection> = emptyList()
    private var scaleFactor: Float = 1f
    private var imageWidth: Int = 1
    private var imageHeight: Int = 1

    private val boxPaint = Paint().apply {
        color = ContextCompatColor(context, R.color.boxColor)
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }

    private val textBackgroundPaint = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.FILL
        alpha = 180
    }

    private val textPaint = Paint().apply {
        color = ContextCompatColor(context, R.color.textColor)
        textSize = 42f
        style = Paint.Style.FILL
    }

    fun setResults(
        detectionResults: List<Detection>,
        imageHeight: Int,
        imageWidth: Int
    ) {
        results = detectionResults
        this.imageHeight = imageHeight
        this.imageWidth = imageWidth

        // PreviewView uses FILL_CENTER-like scaling; compute scale so
        // boxes line up with what's on screen.
        scaleFactor = max(width * 1f / imageWidth, height * 1f / imageHeight)
        invalidate()
    }

    override fun draw(canvas: Canvas) {
        super.draw(canvas)

        for (detection in results) {
            val box = detection.boundingBox()

            val left = box.left * scaleFactor
            val top = box.top * scaleFactor
            val right = box.right * scaleFactor
            val bottom = box.bottom * scaleFactor

            canvas.drawRect(left, top, right, bottom, boxPaint)

            val category = detection.categories().firstOrNull()
            val label = category?.categoryName() ?: "object"
            val score = category?.score() ?: 0f
            val displayText = "$label ${"%.0f".format(score * 100)}%"

            val textWidth = textPaint.measureText(displayText)
            val textHeight = textPaint.textSize

            canvas.drawRect(
                left,
                top,
                left + textWidth + 16f,
                top + textHeight + 16f,
                textBackgroundPaint
            )
            canvas.drawText(displayText, left + 8f, top + textHeight, textPaint)
        }
    }

    fun clear() {
        results = emptyList()
        invalidate()
    }
}

// Small helper so we don't need an extra androidx.core import block above
private fun ContextCompatColor(context: Context, colorRes: Int): Int {
    return androidx.core.content.ContextCompat.getColor(context, colorRes)
}
